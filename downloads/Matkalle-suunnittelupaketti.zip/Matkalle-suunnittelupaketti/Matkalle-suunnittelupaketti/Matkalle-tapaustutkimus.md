# Matkalle — UX/UI-tapaustutkimuksen työpohja

Tekijä: Karine Heinonen. Versio 0.1, 18.10.2026. Tila: ensimmäinen tekoälyavusteinen konsepti ja verkkodemo. Käyttäjätutkimus ja käytettävyystestaus ovat tekemättä. Täytä hakasulkeissa olevat kohdat omalla työlläsi ja todellisilla havainnoilla.

Figma-prototyyppi: https://www.figma.com/design/rmlkjd0VnSlmzUqju4ktjN/Matkalle-%E2%80%94-UX-UI-portfoliokonsepti?node-id=0-1

Tiedoston katselu on avoin. Muokkaus edellyttää kirjautumista Figmaan.

## 1. Lähtökohta

Matkalle on itsenäinen portfoliokonsepti, jossa tutkitaan reitin ja sopivan lipun valintaa. Konsepti on rajattu yhteen asiointiketjuun. Palvelu ei ole HSL:n tilaama tai virallinen HSL-palvelu.

Suunnitteluhypoteesi: satunnainen matkustaja voi tarvita apua reitin, vyöhykkeiden ja lipun yhdistämiseen. Hypoteesi ei ole tutkimustulos.

Tutkimuskysymys: ymmärtääkö käyttäjä ilman ulkopuolista apua, mikä lippu sopii valittuun esimerkkimatkaan ja miksi?

Käyttäjän tavoite: löytää tilanteeseen sopiva reitti, ymmärtää lipun kattavuus ja vahvistaa valinta luottavaisesti.

Liiketoiminnallinen hypoteesi: selkeästi perusteltu lipun valinta voisi vähentää keskeytyksiä ja virheellisiä valintoja. Tätä vaikutusta ei ole mitattu.

## 2. Oma rooli ja yhteistyö

Ensimmäisen version luonnostelussa käytettiin tekoälyä käyttäjäpolun, käyttöliittymätekstien, visuaalisen luonnoksen, koodin ja tutkimuspohjien tuottamiseen. Seuraavat osuudet täydennetään oman työn perusteella:

- Omalla vastuullani: [täytä]
- Tekemäni suunnitteluratkaisut: [täytä]
- Tarkastamani ja muuttamani tekoälyn ehdotukset: [täytä]
- Osallistujien rekrytointi ja testien toteutus: [täytä]
- Yhteistyö muiden kanssa: [täytä tai merkitse itsenäinen työ]
- Käytetyt työkalut ja projektin todellinen kesto: [täytä]

Älä esitä itsenäistä projektia kehittäjätiimin kanssa toteutettuna työnä. Voit näyttää toteutusta tukevat komponenttikuvaukset, tilat, hyväksymiskriteerit ja oman toteutuksen tarkastuksen.

## 3. Rajaus

Kuusi päävaihetta: reittihaku, vaihtoehdot, reitin tiedot, lipun valinta, yhteenveto, demovahvistus. Haku on rajattu muutamaan esimerkkipaikkaan. Lisäksi suosikkimatkat, jaettava reittisuunnitelma ja maksun virhetilanne.

Kaikki reitit, linjat, aikataulut, hinnat ja lipun voimassaoloajat ovat esimerkkejä. Kartta on kaavio. Ei oikeaa maksua, oikeaa lippua, kirjautumista, liikennedataa tai HSL:n integraatiota. Jaettava linkki havainnollistaa siirtymistä verkkoselaimesta toiseen laitteeseen; se ei ole tuotannollinen HSL-tilin tai sovelluksen integraatio.

## 4. Haastattelut

Tavoite: 3–5 henkilöä, joilla on erilainen kokemus seudulla liikkumisesta. Pieni otos auttaa tunnistamaan ongelmia, mutta ei osoita niiden yleisyyttä koko käyttäjäkunnassa.

Kysy ennen prototyypin näyttämistä:

1. Kerro viimeisimmästä matkasta, jolla jouduit etsimään sopivan reitin tai lipun.
2. Mitä teit ensin ja miksi?
3. Mistä tiesit, että valitsemasi lippu riittää?
4. Mikä oli epäselvää? Miten ratkaisit tilanteen?
5. Miten vertaat matka-aikaa, kävelyä ja vaihtoja?
6. Käytätkö joskus useampaa laitetta saman matkan suunnitteluun?

Pyydä lupa muistiinpanoihin. Käytä koodeja P01–P05. Kirjaa vain tutkimuskysymykseen tarvittavat tiedot. Älä syötä tunnistettavia haastattelutietoja tekoälylle.

Havaintorivi: osallistujakoodi | tilanne | havainto tai tarkka lainaus | oma tulkinta | avoin kysymys. Pidä havainto ja tulkinta erillään.

## 5. Suunnitteluvaihtoehdot

Vaihtoehto A, toteutettu luonnokseen: reittivaihtoehdot ensin, lipun perustelu omassa vaiheessaan. Oletus: päätöksiä voidaan jäsentää vaiheittain.

Vaihtoehto B, vertailtava luonnoksena: kunkin reittikortin yhteydessä näytetään lipun vyöhyke ja esimerkkihinta. Oletus: käyttäjä arvioi matkavaihtoehtoja mieluummin reitin ja kustannuksen yhdistelmänä.

Piirrä myös B:stä vähintään reittivaihtoehtojen Figma-näkymä. Kirjaa, kumpi vaihtoehto tukee käyttäjien esiin nostamaa päätöksentekoa, ja perustele valinta. Älä ilmoita A:n paremmuutta ennen arviointia.

## 6. Käytettävyystesti

Tavoite: 3–5 ohjattua testiä. Kerro, että testaat käyttöliittymää. Osallistujaa ei testata. Näytä, että reitit ja hinnat ovat esimerkkejä.

Tehtävä 1: Olet Pasilan asemalla ja menossa Meilahteen esimerkkipäivänä klo 10.15. Etsi sinulle sopiva matka ja etene lipun vahvistukseen. Kerro omin sanoin, miksi valittu lippu sopii matkaan.

Tehtävä 2: Haluat kävellä mahdollisimman vähän. Etsi tähän tilanteeseen sopiva vaihtoehto. Älä anna osallistujalle etukäteen käyttöliittymän painikkeen nimeä.

Tehtävä 3: Tarkastele lentoasemalle suuntautuvaa esimerkkimatkaa. Selitä, miten lipun kattavuus eroaa aiemmasta matkasta.

Tehtävä 4: Näytä maksun virhetilanne testityökaluista. Kysy: mitä tapahtui, veloitettiinko mitään ja mitä tekisit seuraavaksi?

Tehtävä 5: Tallenna matka ja etsi se uudelleen. Kokeile halutessasi reittisuunnitelman linkin avaamista toisella laitteella. Julkinen demo-osoite on https://karinehei.github.io/Matkalle-GitHub-Pages/, kun sivusto on julkaistu `main`-haaran juuresta. Osoite `karinehei.github.io/matkalle` ei avaa tätä demoa. Yksityisen repositorion osoite ei anna muille pääsyä. Tallennettu matka säilyttää lipputyypin sellaisena kuin se oli tallennushetkellä.

Kirjaa tehtävittäin: onnistui itsenäisesti / onnistui avustettuna / keskeytyi, aloitus- ja lopetusaika, väärät valinnat, avun tarve, käyttäjän selitys sekä tehtävän jälkeinen koettu helppous 1–7. Mittaa aika vasta tavoitteen ymmärtämisen jälkeen. Älä johdattele oikeaan lippuun.

Havaintopohja:

| Osallistuja | Tehtävä | Havainto | Seuraus käyttäjälle | Vakavuus ja perustelu | Muutosehdotus |
|---|---|---|---|---|---|
| [täytä] | [täytä] | [täytä] | [täytä] | [täytä] | [täytä] |

## 7. Saavutettavuuden tarkistus

- Koko käyttäjäpolku näppäimistöllä, looginen kohdistus ja näkyvä kohdistusmerkki.
- Sivun vaihtuessa otsikon lukeminen ja kohdistuksen siirtyminen.
- Lomakkeiden nimet, valintojen ryhmittely ja virheiden ymmärrettävyys.
- Reitin sisältö ymmärrettävissä myös ilman karttaa ja värejä.
- 200 % zoomaus, 320 CSS-pikselin leveys ja pitkä sisältö.
- Ruudunlukijalla vähintään yksi kokonainen käyttäjäpolku.
- Kontrastit ja kosketusalueet sekä manuaalinen tarkistus automaattisen tarkistuksen lisäksi.

Nämä ovat tarkistettavia asioita, eivät todistus saavutettavuudesta. Figma-luonnos ei osoita toteutuksen ruudunlukijatoimivuutta. Verkkodemo ei osoita kokemusta oikeasta natiivisovellustoteutuksesta.

## 8. Analytiikka ja AI

Testitapahtumien keruu on vapaaehtoinen ja oletuksena pois päältä. Aktivoi Portfolion testityökalut -osiosta. Tapahtumat näkyvät vain samassa selainvälilehdessä ja ovat ladattavissa JSON-tiedostona. Demossa ei ole GA-integraatiota. Mukana olevat tapahtumat: haku, reitin valinta, lipun valinta, vaiheen avaus, näkymän vaihto, demomaksun epäonnistuminen ja onnistuminen sekä suosikiksi tallennus.

Tapahtumia käytetään ohjattujen testien tukena. Pelkkä tapahtumajono ei selitä käyttäjän motiiveja. Liitä havaintoihin käyttäjän kommentit ja avun tarve. Älä tulkitse omia kehityskokeiluja asiakasanalytiikaksi.

Tekoälypäiväkirja:

| Päivä | Työkalu ja tehtävä | Saadun ehdotuksen ydin | Hyväksyin / muutin / hylkäsin | Peruste ja tarkistus |
|---|---|---|---|---|
| 18.10.2026 | Tekoälyavusteinen ensimmäinen luonnos | Kuusi näkymää, vaiheittainen lipun valinta, esimerkkidata | Arvioitava luonnos | Käyttäjätestit tekemättä |
| [täytä] | [täytä] | [täytä] | [täytä] | [täytä] |

## 9. Iteraatio ja tulokset

Ennen: [kuva ja käyttäjätestin todellinen havainto].

Muutos: [mitä muutit ja mihin havaintoon muutos perustui].

Jälkeen: [uusi kuva ja mahdollinen uudelleentesti].

Tulokset: [raportoi todelliset tehtävät ja osallistujamäärät; ei keksittyjä prosentteja].

Rajoitukset: pieni otos, esimerkkidata, testitilanne, prototyypin rajattu toiminta sekä arvioimattomat käyttäjäryhmät. Vertailua ennen/jälkeen ei pidä kuvata kausaaliseksi tai yleistettäväksi ilman siihen sopivaa asetelmaa.

## 10. Portfolion julkaisu

Tiivistä valmis tapaustutkimus: ongelma ja tavoite, oma rooli, tutkimus, vaihtoehdot ja perusteltu valinta, Figma-komponentit ja pääpolku, toimiva demo, testihavainnot ja muutokset, AI:n rooli sekä rajoitukset. Julkaise vasta kun placeholderit on korvattu. Nimeä itse tehty design system alkuversioksi; älä esitä sitä HSL:n design systeminä.

Seuraava tekninen mahdollisuus on oikean reitti- ja vyöhykedatan liittäminen HSL:n virallisten avoimen datan käyttöehtojen ja ajantasaisten API-ohjeiden mukaisesti. Se on tämän version ulkopuolella.
